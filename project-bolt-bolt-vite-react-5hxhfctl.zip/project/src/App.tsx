import React from 'react';
import { PriceDisplay } from './components/PriceDisplay';
import { useWeb3 } from './hooks/useWeb3';

function App() {
  const { account, error } = useWeb3();

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      {error ? (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
          {error}
        </div>
      ) : (
        <>
          {account && (
            <div className="mb-4 text-sm text-gray-600">
              Connected: {account.slice(0, 6)}...{account.slice(-4)}
            </div>
          )}
          <PriceDisplay />
        </>
      )}
    </div>
  );
}

export default App;