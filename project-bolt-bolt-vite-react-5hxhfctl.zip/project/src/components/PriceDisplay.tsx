import React from 'react';
import { TrendingUp } from 'lucide-react';
import { usePriceFeed } from '../hooks/usePriceFeed';

export const PriceDisplay: React.FC = () => {
  const { price, loading, error } = usePriceFeed();

  if (error) {
    return (
      <div className="text-red-500 p-4 rounded-lg bg-red-100">
        <p>Error: {error}</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-md">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-800">ETH/USD Price Feed</h2>
        <TrendingUp className="text-blue-500 w-6 h-6" />
      </div>
      
      <div className="border-t border-gray-100 pt-4">
        {loading ? (
          <div className="animate-pulse flex space-x-4">
            <div className="h-6 bg-slate-200 rounded w-full"></div>
          </div>
        ) : (
          <div className="flex flex-col">
            <span className="text-3xl font-bold text-gray-900">
              ${Number(price).toLocaleString(undefined, {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </span>
            <span className="text-sm text-gray-500 mt-1">
              Last updated: {new Date().toLocaleTimeString()}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};