import { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import { useWeb3 } from './useWeb3';

const PRICE_FEED_ADDRESS = '0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419'; // ETH/USD Mainnet

export const usePriceFeed = () => {
  const { provider } = useWeb3();
  const [price, setPrice] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPrice = async () => {
      if (!provider) return;

      try {
        const abi = ["function latestRoundData() view returns (uint80, int256, uint256, uint256, uint80)"];
        const priceFeed = new ethers.Contract(PRICE_FEED_ADDRESS, abi, provider);
        
        const [, latestPrice] = await priceFeed.latestRoundData();
        setPrice(ethers.formatUnits(latestPrice, 8));
        setLoading(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch price');
        setLoading(false);
      }
    };

    const interval = setInterval(fetchPrice, 1000);
    return () => clearInterval(interval);
  }, [provider]);

  return { price, loading, error };
};