import { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import { PriceFeed__factory } from '../types/contracts';

export const useWeb3 = () => {
  const [provider, setProvider] = useState<ethers.BrowserProvider | null>(null);
  const [account, setAccount] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const init = async () => {
      try {
        if (window.ethereum) {
          const provider = new ethers.BrowserProvider(window.ethereum);
          const accounts = await provider.send("eth_requestAccounts", []);
          setProvider(provider);
          setAccount(accounts[0]);
        } else {
          throw new Error("Please install MetaMask!");
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
      }
    };

    init();
  }, []);

  return { provider, account, error };
};